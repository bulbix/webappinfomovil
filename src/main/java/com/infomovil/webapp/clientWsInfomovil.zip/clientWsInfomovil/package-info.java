@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.webservice.infomovil.org/")
package com.infomovil.webapp.clientWsInfomovil;
